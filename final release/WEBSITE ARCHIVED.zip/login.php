<?php
   $msg = '';

   if (isset($_POST['login']) && !empty($_POST['uname']) 
      && !empty($_POST['psw'])) {

      if ($_POST['uname'] == '1' && 
         $_POST['psw'] == '1') {
         $_SESSION['valid'] = true;
         $_SESSION['timeout'] = time();
         $_SESSION['uname'] = '1';
         
         echo 'You have entered valid use name and password';
      }else {
         $msg = 'Wrong username or password';
      }
   }
?>